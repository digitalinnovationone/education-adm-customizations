// ==UserScript==
// @name         Admin "course/{id}/change"
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Script que aplica as customizações no domínio de alteração de "Cursos".
// @author       falvojr
// @match        https://sms.dio.me/admin/learning/course/**/change/**
// @icon         https://www.google.com/s2/favicons?domain=dio.me
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const pageName = 'course/course-change.js';

    (function (pageName) {
        const script = document.createElement('script');
        script.src = `https://digitalinnovationone.github.io/education-adm-customizations/js/main.js`;
        const [body] = document.getElementsByTagName('body');
        body.appendChild(script);

        setTimeout(() => {
            window.EducationCustomizations.load(pageName);
        }, 2000);
    })(pageName);

})();