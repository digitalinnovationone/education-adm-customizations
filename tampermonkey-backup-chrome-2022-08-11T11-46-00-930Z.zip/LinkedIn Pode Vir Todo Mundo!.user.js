// ==UserScript==
// @name         LinkedIn Pode Vir Todo Mundo!
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Script topzera pra aceitar automaticamente (a cada X segundos) todos os convites do LinkedIn.
// @author       You
// @match        https://www.linkedin.com/mynetwork/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=linkedin.com
// @grant        none
// ==/UserScript==


(function() {
    'use strict';
     setTimeout(function() { aceitarPorraToda() }, 5000)
})();

function aceitarPorraToda() {
    let botoes = document.querySelectorAll("button[aria-label^='Aceitar o convite de']");
    for (var i = 0; i < botoes.length; i++) {
        let botao = botoes[i];
        console.log(botao.getAttribute("aria-label"));
        botao.click();
    }
    setTimeout(function() { aceitarPorraToda() }, 2000)
}