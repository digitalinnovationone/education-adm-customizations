// ==UserScript==
// @name         Admin Code Challenges Customizations
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Script que inclui ações/botões dinamicamente no domínio de 'codechallenges'.
// @author       falvojr
// @match        https://app.digitalinnovation.one/admin/training/codechallenge/**/change/**
// @icon         https://www.google.com/s2/favicons?domain=dio.me
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const pageName = 'codechallenge';

    (function (pageName) {
        const script = document.createElement('script');
        script.src = `https://digitalinnovationone.github.io/education-adm-customizations/js/main.js`;
        const [body] = document.getElementsByTagName('body');
        body.appendChild(script);

        setTimeout(() => {
            window.EducationCustomizations.load(pageName);
        }, 2000);
    })(pageName);

})();