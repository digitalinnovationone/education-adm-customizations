// ==UserScript==
// @name         Ações Personalizadas - Lab
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Script que inclui ações/botões dinamicamente no domínio de labs.
// @author       falvojr
// @match        https://app.digitalinnovation.one/admin/learning/labproject/**/change/
// @icon         https://www.google.com/s2/favicons?domain=dio.me
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const pageName = 'lab';

    (function (pageName) {
        const script = document.createElement('script');
        script.src = `https://falvojr.github.io/education-adm-customizations/js/main.js`;
        const [body] = document.getElementsByTagName('body');
        body.appendChild(script);

        setTimeout(() => {
            window.EducationCustomizations.load(pageName);
        }, 2000);
    })(pageName);

})();