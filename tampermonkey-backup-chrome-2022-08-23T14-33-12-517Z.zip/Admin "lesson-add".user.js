// ==UserScript==
// @name         Admin "lesson/add"
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Script que aplica as customizações no domínio de inclusão de "Aulas".
// @author       falvojr
// @match        https://app.digitalinnovation.one/admin/learning/lesson/add/**
// @icon         https://www.google.com/s2/favicons?sz=64&domain=digitalinnovation.one
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const scriptPath = 'lesson/lesson-new.js';

    (function (scriptPath) {
        const script = document.createElement('script');
        script.src = `https://digitalinnovationone.github.io/education-adm-customizations/js/main.js`;
        const [body] = document.getElementsByTagName('body');
        body.appendChild(script);

        setTimeout(() => {
            window.EducationCustomizations.load(scriptPath);
        }, 2000);
    })(scriptPath);

})();