// ==UserScript==
// @name         Admin "question/add"
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Script que aplica as customizações no domínio de inclusão de "Questões".
// @author       falvojr
// @match        https://app.digitalinnovation.one/admin/learning/question/add/**
// @icon         https://www.google.com/s2/favicons?sz=64&domain=digitalinnovation.one
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const scriptPath = 'question/question-new.js';

    (function (scriptPath) {
        const script = document.createElement('script');
        script.src = `https://digitalinnovationone.github.io/education-adm-customizations/js/main.js`;
        const [body] = document.getElementsByTagName('body');
        body.appendChild(script);

        setTimeout(() => {
            window.EducationCustomizations.load(scriptPath);
        }, 2000);
    })(scriptPath);

})();